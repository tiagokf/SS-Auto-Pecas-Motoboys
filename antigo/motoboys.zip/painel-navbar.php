
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <button class="toggle-sidebar btn btn-outline-primary">
      <i class="fas fa-bars"></i>
    </button>
    <span class="navbar-text">
      Olá, <?php echo $_SESSION['usuario_nome']; ?>
    </span>
  </div>
</nav>

