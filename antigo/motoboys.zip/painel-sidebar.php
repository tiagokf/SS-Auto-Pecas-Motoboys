
<div class="sidebar">
  <a href="painel.php">Painel</a>  
  <a href="usuarios.php">Usuários</a>
  <a href="motoboys.php">Motoboys</a>
  <a href="movimentos.php">Movimentos</a>
  <a href="logout.php">Logout</a>
</div>
